﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IMSApi.Api
{
	public static class RuleBuilderExtensions
	{
		public static IRuleBuilder<T, string> PasswordRegx<T>(this IRuleBuilder<T, string> ruleBuilder)
		{
			var options = ruleBuilder
						  .NotEmpty()
						  .NotNull()
						  .MinimumLength(8)
						  .MaximumLength(16)
						  .Matches("^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$");
			return options;
		}
	}
}
