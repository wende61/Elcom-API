﻿using FluentValidation;
using IMSApi.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IMSApi.Api
{
	public class SignUpValidator : AbstractValidator<SignUpRequest>
	{
		public SignUpValidator()
		{
			RuleFor(x => x.CompanyName)
				.NotEmpty()
				.Length(2, 30);
		}
	}
}
