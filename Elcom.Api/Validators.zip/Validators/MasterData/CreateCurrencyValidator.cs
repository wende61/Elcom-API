﻿using FluentValidation;
using IMSApi.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IMSApi.Api
{
    public class CreateCurrencyValidator : AbstractValidator<CurrencyRequest>
    {
        public CreateCurrencyValidator()
        {
            RuleFor(x => x.Code)
           .NotEmpty()
           .Matches(expression : "^[a-zA-Z0-9]*$");

            RuleFor(x => x.Name)
           .NotEmpty()
           .Matches(expression: "^[a-zA-Z0-9]*$");
        }
    }
}
