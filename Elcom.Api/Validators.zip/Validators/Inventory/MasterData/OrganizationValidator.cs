﻿using FluentValidation;
using IMSApi.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IMSApi.Api
{
	public class OrganizationValidator : AbstractValidator<OrganizationRequest>
	{
		public OrganizationValidator()
		{
			RuleFor(x => x.Name)
			.NotEmpty();

			RuleFor(x => x.CurrencyId)
			.NotEmpty();

			RuleFor(x => x.CountryId)
			.NotEmpty();
		}
	}
}
