﻿using FluentValidation;
using IMSApi.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IMSApi.Api
{
   

    public class UserAccountValidator : AbstractValidator<UserRequest>
    {
        public UserAccountValidator()
        {
            //RuleFor(x => x.Password).PasswordRegx();
			RuleFor(x => x.Username).EmailAddress();
			RuleFor(x => x.FirstName).MinimumLength(2).MaximumLength(20).NotEmpty().NotNull();
			RuleFor(x => x.LastName).MinimumLength(2).MaximumLength(20).NotEmpty().NotNull();
			RuleFor(x => x.Roles).NotNull();
		}
    }
}
